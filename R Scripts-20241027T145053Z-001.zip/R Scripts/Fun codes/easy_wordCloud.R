# Sample data: Words and their frequencies
words <- c("Data", "Visualization", "R", "Word", "Cloud", "Plot", "Text", "Analysis", "Statistics", "Graph")
frequencies <- c(20, 15, 30, 10, 25, 10, 5, 12, 8, 18)

# Create word cloud
wordcloud(words = words,
          freq = frequencies,
          min.freq = 1,
          max.words = 100,
          random.order = FALSE,
          colors = brewer.pal(8, "Dark2"))
