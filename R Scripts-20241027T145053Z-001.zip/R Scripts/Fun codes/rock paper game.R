# Simple Rock, Paper, Scissors Game
play_rps <- function() {
  options <- c("rock", "paper", "scissors")
  computer_choice <- sample(options, 1)
  
  cat("Choose rock, paper, or scissors:\n")
  user_choice <- readline(prompt = "Your choice: ")
  
  if (user_choice %in% options) {
    cat("Computer chose:", computer_choice, "\n")
    
    if (user_choice == computer_choice) {
      cat("It's a tie!\n")
    } else if ((user_choice == "rock" && computer_choice == "scissors") ||
               (user_choice == "paper" && computer_choice == "rock") ||
               (user_choice == "scissors" && computer_choice == "paper")) {
      cat("You win!\n")
    } else {
      cat("You lose!\n")
    }
  } else {
    cat("Invalid choice. Please select rock, paper, or scissors.\n")
  }
}

# Run the game
play_rps()
