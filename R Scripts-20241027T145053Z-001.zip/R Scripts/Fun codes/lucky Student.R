# Generate a "lucky" student number
students <- 1:30  # Replace 30 with the actual number of students in class
lucky_student <- sample(students, 1)

paste("Lucky Student:", lucky_student)