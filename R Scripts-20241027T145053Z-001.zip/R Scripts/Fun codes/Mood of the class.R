# Simple mood indicators using emojis
moods <- c("😀", "😊", "😐", "😞", "😡")
names(moods) <- c("Happy", "Content", "Neutral", "Sad", "Angry")

# Pick a random mood
sample_mood <- sample(moods, 1)
paste("Class Mood Today:", sample_mood)