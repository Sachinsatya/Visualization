# Random color generator
random_color <- function() {
  color <- rgb(runif(1), runif(1), runif(1) )
  plot(1:10, col=color, pch=16, cex=10, main=paste("Random Color:", color))
}

# Generate and display a random color
random_color()