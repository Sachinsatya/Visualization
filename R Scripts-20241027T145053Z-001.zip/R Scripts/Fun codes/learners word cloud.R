# Install packages if not already installed
install.packages("wordcloud")
install.packages("RColorBrewer")

# Load libraries
library(wordcloud)
library(RColorBrewer)

# Sample data: Students' names and frequency of occurrence
names <- c("Alice", "Bob", "Charlie", "Daisy", "Eli", "Fiona", "George", "Hannah")
freq <- sample(1:10, length(names), replace = TRUE)

# Create a word cloud
wordcloud(words = names, freq = freq, min.freq = 1, max.words = 100,
          random.order = FALSE, colors = brewer.pal(8, "Dark2"))
