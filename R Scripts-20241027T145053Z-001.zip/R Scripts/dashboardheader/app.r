library(shiny)
library(shinydashboard)
ui<-dashboardPage(
  dashboardHeader(title= "My Dashboard"),
  
  dashboardSidebar(
    menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
    menuItem("Widgets", icon = icon("th"), tabName = "widgets",
             badgeLabel = "new", badgeColor = "green")
  ),
  dashboardBody(
     
    use_theme(mytheme),
    box(plotOutput("correlation_plot"), width=8),
    box(
      selectInput("features", "features:",
                  c("Sepal.Width", "Petal.Length", "Petal.Width")), width=4
    ),
    tabItems(
      tabItem(tabName = "dashboard",
              h2("Dashboard tab content")
      ),
      
      tabItem(tabName = "widgets",
              h2("Widgets tab content")
      )
    )
  ),
)


server <- function(input, output){
  output$correlation_plot<- renderPlot({
    plot(iris$Sepal.Length, iris[[input$features]],
         xlab="Sepal Length", ylab="Features")
  })
} 

shinyApp(ui, server)

