install.packages("wordcloud2")
library(wordcloud2)
wordcloud2(data=demoFreq)
head(demoFreq)
wordcloud2(demoFreq,color="random-light",backgroundColor = "grey")
wordcloud2(demoFreq, minRotation = -pi/6, maxRotation = -pi/6, minSize = 10,
           rotateRatio = 1)
