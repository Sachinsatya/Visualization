# Load library
library(ggplot2)

# Sample data
data <- data.frame(
  category = c("A", "B", "C", "D"),
  values = c(30, 20, 35, 15)
)

# Donut chart
ggplot(data, aes(x = 2, y = values, fill = category)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar(theta = "y") +
  xlim(0.5, 2.5) +
  labs(title = "Donut Chart") +
  theme_void() +
  theme(legend.position = "right")
