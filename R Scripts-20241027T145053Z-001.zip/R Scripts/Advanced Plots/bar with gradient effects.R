# Load library
library(ggplot2)

# Sample data
data <- data.frame(
  category = c("A", "B", "C", "D"),
  values = c(15, 25, 30, 10)
)

# Bar chart with gradient
ggplot(data, aes(x = category, y = values, fill = values)) +
  geom_bar(stat = "identity") +
  scale_fill_gradient(low = "skyblue", high = "navy") +
  labs(title = "Bar Chart with Gradient Colors", x = "Category", y = "Values") +
  theme_minimal()