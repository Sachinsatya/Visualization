# Load library
library(ggplot2)

# Sample data
data <- data.frame(
  category = c("A", "B", "C", "D", "E"),
  values = c(10, 15, 7, 20, 12)
)

# Lollipop chart
ggplot(data, aes(x = category, y = values)) +
  geom_segment(aes(x = category, xend = category, y = 0, yend = values), color = "skyblue") +
  geom_point(color = "blue", size = 5) +
  labs(title = "Lollipop Chart", x = "Category", y = "Values") +
  theme_minimal()