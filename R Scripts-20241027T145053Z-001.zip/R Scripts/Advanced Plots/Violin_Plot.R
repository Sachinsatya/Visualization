# Sample data
data <- data.frame(
  category = rep(c("A", "B", "C"), each = 100),
  value = c(rnorm(100, mean = 5), rnorm(100, mean = 7), rnorm(100, mean = 6))
)

# Violin plot
ggplot(data, aes(x = category, y = value, fill = category)) +
  geom_violin(trim = FALSE) +
  labs(title = "Violin Plot", x = "Category", y = "Value") +
  theme_minimal()
