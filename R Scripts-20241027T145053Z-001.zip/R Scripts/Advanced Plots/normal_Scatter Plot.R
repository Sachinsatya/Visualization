# Load ggplot2 package
library(ggplot2)

# Sample data
data <- data.frame(x = rnorm(100), y = rnorm(100))

# Scatter plot
ggplot(data, aes(x = x, y = y)) +
  geom_point(color = 'blue') +
  labs(title = "Scatter Plot", x = "X-axis", y = "Y-axis")
