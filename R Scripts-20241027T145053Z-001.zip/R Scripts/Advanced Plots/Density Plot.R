library(ggplot2)

# Sample data
data <- data.frame(values = rnorm(1000, mean = 5, sd = 2))

# Density plot
ggplot(data, aes(x = values)) +
  geom_density(fill = "purple", alpha = 0.5) +
  labs(title = "Density Plot", x = "Values") +
  theme_minimal()
