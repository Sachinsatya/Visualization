# Load necessary library
library(ggplot2)

# Sample data
data <- data.frame(
  category = factor(LETTERS[1:10]),
  value = sample(1:100, 10)
)

# Circular bar plot
ggplot(data, aes(x = category, y = value)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  coord_polar() +
  labs(title = "Circular Bar Plot", x = "", y = "") +
  theme_minimal()