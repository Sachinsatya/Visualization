# Load library
library(ggplot2)

# Sample data
data <- data.frame(
  category = rep(c("Group 1", "Group 2", "Group 3"), each = 20),
  values = c(rnorm(20, mean = 5), rnorm(20, mean = 7), rnorm(20, mean = 6))
)

# Box plot with jitter
ggplot(data, aes(x = category, y = values, fill = category)) +
  geom_boxplot(alpha = 0.6) +
  geom_jitter(width = 0.2, color = "black", alpha = 0.6) +
  labs(title = "Box Plot with Jitter", x = "Group", y = "Values") +
  theme_minimal()
