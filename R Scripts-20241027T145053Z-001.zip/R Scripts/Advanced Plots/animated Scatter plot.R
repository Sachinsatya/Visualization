# Load libraries
library(ggplot2)
library(gganimate)

# Sample data
set.seed(123)
data <- data.frame(
  time = rep(1:10, each = 10),
  x = rnorm(100),
  y = rnorm(100)
)

# Scatter plot with animation
p <- ggplot(data, aes(x = x, y = y)) +
  geom_point(color = "blue", size = 3) +
  labs(title = "Animated Scatter Plot", x = "X-axis", y = "Y-axis") +
  transition_time(time) +
  ease_aes('linear') +
  theme_minimal()

# Animate the plot
animate(p, nframes = 30, width = 600, height = 400)
