# Sample data
data <- data.frame(
  x = rep(1:10, each = 10),
  y = rep(1:10, times = 10),
  value = rnorm(100)
)

# Heatmap
ggplot(data, aes(x = x, y = y, fill = value)) +
  geom_tile() +
  scale_fill_gradient(low = "blue", high = "red") +
  labs(title = "Heatmap", x = "X-axis", y = "Y-axis") +
  theme_minimal()
