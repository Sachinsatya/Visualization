# Load plotly library
library(plotly)

# Sample data
data <- data.frame(
  x = rnorm(100),
  y = rnorm(100, mean = 2),
  z = rnorm(100, mean = 5)
)

# 3D Scatter plot
plot_ly(data, x = ~x, y = ~y, z = ~z, type = 'scatter3d', mode = 'markers') %>%
  layout(title = "3D Scatter Plot")
