# Load library
library(ggplot2)

# Sample data
data <- data.frame(
  category = factor(letters[1:8]),
  values = sample(1:20, 8)
)

# Polar area chart
ggplot(data, aes(x = category, y = values, fill = category)) +
  geom_bar(stat = "identity") +
  coord_polar() +
  labs(title = "Polar Area Chart") +
  theme_void()