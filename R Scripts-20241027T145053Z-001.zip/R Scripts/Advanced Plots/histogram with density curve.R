# Load library
library(ggplot2)

# Sample data
data <- data.frame(values = rnorm(1000))

# Histogram with density curve
ggplot(data, aes(x = values)) +
  geom_histogram(aes(y = ..density..), bins = 30, fill = "skyblue", color = "white", alpha = 0.6) +
  geom_density(color = "navy", size = 1) +
  labs(title = "Histogram with Density Curve", x = "Values", y = "Density") +
  theme_minimal()