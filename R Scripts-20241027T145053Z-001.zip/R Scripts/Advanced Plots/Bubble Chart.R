# Sample data
data <- data.frame(
  x = rnorm(30),
  y = rnorm(30),
  size = runif(30, min = 1, max = 10)
)

# Bubble chart
ggplot(data, aes(x = x, y = y, size = size, color = size)) +
  geom_point(alpha = 0.6) +
  scale_size(range = c(2, 10)) +
  labs(title = "Bubble Chart", x = "X-axis", y = "Y-axis") +
  theme_minimal()
