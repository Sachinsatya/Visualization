#advanced plots in R
#manual method
install.packages("ggplot2")
library(ggplot2)
ggplot(mpg, aes(x=displ, y=hwy))+ 
  geom_point()
View(mpg)
ggplot(mpg, aes(x=displ, y=hwy))+ 
  geom_count()
ggplot(mpg, aes(cty, hwy))+ 
  geom_point()
ggplot(diamonds, aes(carat, price))+
  geom_point()
ggplot(economics, aes(date, unemploy)) +
  geom_line()
ggplot(mpg, aes(cty))+
  geom_histogram()
ggplot(mpg, aes(displ,cty, color= class))+ 
  geom_point()
str(mpg)
ggplot(mpg, aes(displ,hwy))+
  geom_point()+
  facet_wrap(~class)
ggplot(mpg, aes(displ,hwy))+
  geom_point()+
  facet_wrap(vars(cyl, drv))
ggplot(mpg, aes(displ, hwy))+
  geom_point()+
  facet_wrap(vars(cyl,drv),
             labeller="label_both")
mpg$class2<- reorder(mpg$class, mpg$displ)
mpg$class2
ggplot(mpg, aes(displ, hwy))+
  geom_point()+
  facet_wrap(vars(class2))
ggplot(mpg,aes(displ,hwy))+
  geom_point()+
  facet_wrap(vars(class), scales="free")
ggplot(mpg, aes(displ,hwy)) +
  geom_point(data=transform(mpg, class=NULL), colour= "grey85")+
  geom_point()+
  facet_wrap(vars(class))
ggplot(economics_long,aes(date,value))+
  geom_line()+
  facet_wrap(vars(variable), scales= "free_y",nrow=2, strip.position = "top")
+
  theme(strip.background= element_blank(),strip.placement = "outside")
ggplot(mpg,aes(displ,hwy))+
  geom_point()+
  geom_smooth()
ggplot(mpg,aes(displ,hwy))+
  geom_point()+
  geom_smooth(se=FALSE)
ggplot(mpg,aes(displ,hwy))+
  geom_point()+
  geom_smooth(span=0.2)
ggplot(mpg, aes(displ,hwy))+
  geom_point()+
  geom_smooth(method= "lm", se=F)
ggplot(mpg, aes(drv,hwy)) +
  geom_point()
ggplot(mpg, aes(drv,hwy))+ geom_jitter()
ggplot(mpg,aes(drv,hwy))+ geom_boxplot()
ggplot(mpg,aes(drv,hwy))+ geom_violin()
ggplot(mpg,aes(hwy))+ geom_freqpoly()
ggplot(mpg,aes(hwy))+ geom_histogram()
ggplot(mpg,aes(hwy))+ geom_freqpoly(binwidth=2.5)
ggplot(mpg,aes(hwy))+ geom_freqpoly(binwidth=1)
ggplot(mpg,aes(displ, color=drv))+geom_freqpoly(binwidth=0.5)
ggplot(mpg,aes(displ, color=drv))+geom_histogram(binwidth = 0.5)
ggplot(mpg,aes(displ, color=drv))+geom_histogram(binwidth = 0.5)+
  facet_wrap(~ drv,ncol=1)
ggplot(mpg,aes(displ, fill=drv))+geom_histogram(binwidth = 0.5)+
  facet_wrap(~ drv,ncol=1)
ggplot(mpg,aes(displ, fill=drv))+geom_histogram(binwidth = 0.5)+
  facet_wrap(~ drv,ncol=2)
ggplot(mpg,aes(manufacturer))+ geom_bar()
qplot(manufacturer, data=mpg, geom="bar", fill=manufacturer)
ggplot(data = mpg) +
  geom_smooth(
    mapping = aes(x = displ, y = hwy, color = drv),
    show.legend = FALSE
  )
ggplot(data = mpg, mapping = aes(x = displ, y = hwy)) + 
  geom_point(mapping=aes(color=class)) +
  geom_smooth()
ggplot(data = mpg) + 
  geom_point(mapping = aes(y = drv, x = cyl, color=factor(cyl)), size=4)
ggplot(data = mpg) + 
  geom_point(mapping = aes(x = displ, y = hwy, color=cyl)) +
  facet_grid(. ~ cyl)

